| `Version` | `Update Notes`    |
|-----------|-------------------|
| 1.0.1     | - Minor fix       |
| 1.0.0     | - Initial Release |